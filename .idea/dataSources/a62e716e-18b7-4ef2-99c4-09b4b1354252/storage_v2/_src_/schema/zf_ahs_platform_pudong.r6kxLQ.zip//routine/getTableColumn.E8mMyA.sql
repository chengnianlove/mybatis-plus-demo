create
    definer = root@`%` function getTableColumn(p_library_name varchar(100), p_tableName varchar(500),
                                               p_type varchar(2)) returns text
BEGIN
	DECLARE v_columnName VARCHAR ( 500 ) DEFAULT '';
	DECLARE v_names text DEFAULT '';
	#创建结束标志变量  
	declare done int default false;  
	#创建游标
	DECLARE cur_test CURSOR FOR SELECT COLUMN_NAME  FROM information_schema.COLUMNS WHERE table_name = p_tableName and TABLE_SCHEMA = p_library_name;
	#指定游标循环结束时的返回值  
	DECLARE CONTINUE HANDLER FOR NOT FOUND 
		SET done = 1;
	
	#打开游标
	OPEN cur_test;
	#执行循环 
	posLoop : LOOP
		#取游标中的值
		FETCH cur_test INTO v_columnName;
		#判断是否结束循环
		IF done = 1 THEN
				LEAVE posLoop;
			
		END IF;
		
		if p_type = '1' then
			SET v_names = CONCAT(v_names, v_columnName, ',');
		else 
			SET v_names = CONCAT(v_names, ' \' ,  checkEmptyStr(REPLACE(REPLACE(REPLACE(', v_columnName, ',CHAR(13),\'\\\\n\'),CHAR(10),\'\\\\n\'), \'\\\'\', \'\\\\\\\'\')), \' ', ',');
			#SET v_names = CONCAT(v_names, ' \'\'\' ,  ', v_columnName, ', \'\'\' ', ',');
		end if;
		
	END LOOP posLoop;
	
	CLOSE cur_test;
	set v_names = left(v_names, LENGTH(v_names)-1);
	RETURN v_names;

END;

