create
    definer = root@`%` procedure new_procedure()
BEGIN
	DECLARE tableName varCHAR(200);
	DECLARE cal2 VARCHAR(800);
	-- 遍历数据结束标志
  DECLARE done INT DEFAULT FALSE;

	DECLARE cur CURSOR FOR select table_name from t_exchange_back_table;
  -- 将结束标志绑定到游标
  DECLARE CONTINUE HANDLER FOR NOT FOUND SET done = TRUE;
  -- 打开游标
  OPEN cur;
  
  -- 开始循环
  read_loop: LOOP
    -- 提取游标里的数据，这里只有一个，多个的话也一样；
    FETCH cur INTO tableName;
    -- 声明结束的时候
    IF done THEN
      LEAVE read_loop;
    END IF;
		if tableName is not null then
			set cal2 = concat('DROP TABLE IF EXISTS ', tableName);

			SET @sql2=cal2;
			-- 这里做你想做的循环的事件
			PREPARE stmt2 FROM @sql2;
			EXECUTE stmt2;
		end if;
    -- INSERT INTO test.t VALUES (a);

  END LOOP;
  -- 关闭游标
  CLOSE cur;
END;

