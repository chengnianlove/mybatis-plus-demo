create definer = root@localhost view v_situation as
select `s`.`OID` AS `OID`, `s`.`PACKAGE_OID` AS `PACKAGE_OID`, `s`.`PAC_SITUATION_NAME` AS `PAC_SITUATION_NAME`
from `zf_ahs_platform_pudong`.`t_pac_situation` `s`
where (`s`.`DELETE_STATUS` = 'N');

