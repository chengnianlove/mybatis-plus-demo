create
    definer = root@`%` procedure demo_in(IN p1 varchar(200))
BEGIN
SET @a=0;
SET @c=100;
SET @b=10000;
WHILE @a<=1000000 DO
INSERT INTO t_sys_user 
VALUES(CONCAT('useroid',@a),CONCAT('name',@a),'00000000000000000000000000000000',NULL,'M','18663186965','0101110000','digu2012@126.com',@a,NOW(),NULL,'Y','N','123456789012345678','职位', NULL);
INSERT INTO t_sys_login
VALUES(CONCAT('loginoid',@a),'00000000000000000000000000000000',CONCAT('useroid',@a),CONCAT('account',@a),'202cb962ac59075b964b07152d234b70',CONCAT('name',@a),0,'N','Y','N',NULL,NULL);
INSERT INTO t_sys_login_role
VALUES(CONCAT('loginroleoid',@a),CONCAT('loginoid',@a),'4028800557dc11a80157dc18d1fe0002');
SET @a=@a+1;
SET @b=@b+1;
SET @c=@c+1;
END WHILE;
END;

