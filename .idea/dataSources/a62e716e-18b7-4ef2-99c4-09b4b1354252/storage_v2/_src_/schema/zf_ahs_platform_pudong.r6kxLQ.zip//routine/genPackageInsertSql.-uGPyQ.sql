create
    definer = root@`%` procedure genPackageInsertSql(IN p_library_name varchar(100), IN p_packageOid varchar(100))
BEGIN
	DECLARE v_sql TEXT  DEFAULT '';
	DECLARE v_tableName VARCHAR(200) DEFAULT '';
	
	#不存在则创建临时表
	create temporary table if not exists insertSql (
		sql_result LONGTEXT 
	);
	#使用前先清空临时表。
	truncate TABLE insertSql;  
	
	insert into insertSql values ('CREATE PROCEDURE insert_sql_proc()  begin');
	insert into insertSql values ('	DECLARE msg text;');
	insert into insertSql values ('	DECLARE CONTINUE HANDLER FOR SQLEXCEPTION ');
	insert into insertSql values ('	begin get diagnostics condition 1  msg = message_text;set @error = 1; end;');
	insert into insertSql values ('	START TRANSACTION;');
	
	#套餐主体
	set v_tableName = concat('t_pac_subject');
	insert into insertSql (sql_result) values (CONCAT('DELETE from ', v_tableName, ' where OID in (select subject_oid from t_pac_package where  oid = ''', p_packageOid, ''');'));
	set v_sql = CONCAT('insert into insertSql(sql_result) SELECT CONCAT_WS('''',''insert into ', v_tableName, '(', getTableColumn(p_library_name, v_tableName, 1), ') values (', getTableColumn(p_library_name, v_tableName, 0), ');'') FROM ', v_tableName, ' WHERE OID in (select subject_oid from t_pac_package where  oid = ''', p_packageOid, ''');');
	set @sql = v_sql;
	PREPARE s1 from @sql; 
	EXECUTE s1; 

	#套餐信息
	set v_tableName = concat('t_pac_package');
	insert into insertSql (sql_result) values (CONCAT('DELETE from ', v_tableName, ' where oid = ''', p_packageOid, ''';'));
	set v_sql = CONCAT('insert into insertSql(sql_result) SELECT CONCAT_WS('''',''insert into ', v_tableName, '(', getTableColumn(p_library_name, v_tableName, 1), ') values (', getTableColumn(p_library_name, v_tableName, 0), ');'') FROM ', v_tableName, ' WHERE oid = ''', p_packageOid, ''';');
	set @sql = v_sql;
	PREPARE s1 from @sql; 
	EXECUTE s1; 
	#修改业态为不上线
	insert into insertSql (sql_result) values (CONCAT('update ', v_tableName, ' set EXTEND_URL=\'OffLine\' where oid = ''', p_packageOid, ''';'));
	
	#套餐智能问答分类
	set v_tableName = concat('t_pac_situation_type');
	insert into insertSql (sql_result) values (CONCAT('DELETE from ', v_tableName, ' where package_oid = ''', p_packageOid, ''';'));
	set v_sql = CONCAT('insert into insertSql(sql_result) SELECT CONCAT_WS('''',''insert into ', v_tableName, '(', getTableColumn(p_library_name, v_tableName, 1), ') values (', getTableColumn(p_library_name, v_tableName, 0), ');'') FROM ', v_tableName, ' WHERE package_oid = ''', p_packageOid, ''';');
	set @sql = v_sql;
	PREPARE s1 from @sql; 
	EXECUTE s1; 
	
	#套餐智能问答
	set v_tableName = concat('t_pac_situation');
	insert into insertSql (sql_result) values (CONCAT('DELETE from ', v_tableName, ' where package_oid = ''', p_packageOid, ''';'));
	set v_sql = CONCAT('insert into insertSql(sql_result) SELECT CONCAT_WS('''',''insert into ', v_tableName, '(', getTableColumn(p_library_name, v_tableName, 1), ') values (', getTableColumn(p_library_name, v_tableName, 0), ');'') FROM ', v_tableName, ' WHERE package_oid = ''', p_packageOid, ''';');
	set @sql = v_sql;
	PREPARE s1 from @sql; 
	EXECUTE s1; 
	
	#套餐智能问答选项
	set v_tableName = concat('t_pac_option');
	insert into insertSql (sql_result) values (CONCAT('DELETE from ', v_tableName, ' where PAC_SITUATION_OID in (select oid from t_pac_situation where package_oid=''', p_packageOid, ''');'));
	set v_sql = CONCAT('insert into insertSql(sql_result) SELECT CONCAT_WS('''',''insert into ', v_tableName, '(', getTableColumn(p_library_name, v_tableName, 1), ') values (', getTableColumn(p_library_name, v_tableName, 0), ');'') FROM ', v_tableName, ' WHERE PAC_SITUATION_OID in (select oid from t_pac_situation where package_oid=''', p_packageOid, ''');');
	set @sql = v_sql;
	PREPARE s1 from @sql; 
	EXECUTE s1; 
	
	#套餐字段类别
	set v_tableName = concat('t_fill_field_type');
	insert into insertSql (sql_result) values (CONCAT('DELETE from ', v_tableName, ' where package_oid = ''', p_packageOid, ''';'));
	set v_sql = CONCAT('insert into insertSql(sql_result) SELECT CONCAT_WS('''',''insert into ', v_tableName, '(', getTableColumn(p_library_name, v_tableName, 1), ') values (', getTableColumn(p_library_name, v_tableName, 0), ');'') FROM ', v_tableName, ' WHERE package_oid = ''', p_packageOid, ''';');
	set @sql = v_sql;
	PREPARE s1 from @sql; 
	EXECUTE s1; 
	
	#套餐字段信息
	set v_tableName = concat('t_fill_field');
	insert into insertSql (sql_result) values (CONCAT('DELETE from ', v_tableName, ' where FIELD_TYPE_OID in (select oid from t_fill_field_type where package_oid=''', p_packageOid, ''');'));
	set v_sql = CONCAT('insert into insertSql(sql_result) SELECT CONCAT_WS('''',''insert into ', v_tableName, '(', getTableColumn(p_library_name, v_tableName, 1), ') values (', getTableColumn(p_library_name, v_tableName, 0), ');'') FROM ', v_tableName, ' WHERE FIELD_TYPE_OID in (select oid from t_fill_field_type where package_oid=''', p_packageOid, ''');');
	set @sql = v_sql;
	PREPARE s1 from @sql; 
	EXECUTE s1; 
	
	#套餐字段选项信息
	set v_tableName = concat('t_fill_field_option');
	insert into insertSql (sql_result) values (CONCAT('DELETE from ', v_tableName, ' where FIELD_OID in (select oid from t_fill_field where FIELD_TYPE_OID in (select oid from t_fill_field_type where package_oid=''', p_packageOid, '''));'));
	set v_sql = CONCAT('insert into insertSql(sql_result) SELECT CONCAT_WS('''',''insert into ', v_tableName, '(', getTableColumn(p_library_name, v_tableName, 1), ') values (', getTableColumn(p_library_name, v_tableName, 0), ');'') FROM ', v_tableName, ' WHERE FIELD_OID in (select oid from t_fill_field where FIELD_TYPE_OID in (select oid from t_fill_field_type where package_oid=''', p_packageOid, '''));');
	set @sql = v_sql;
	PREPARE s1 from @sql; 
	EXECUTE s1; 
	
	#材料库
	set v_tableName = concat('t_pac_library_material');
	insert into insertSql (sql_result) values (CONCAT('DELETE from ', v_tableName, ' where OID in (select material_oid from t_pac_package_material_rel where package_oid=''', p_packageOid, ''');'));
	set v_sql = CONCAT('insert into insertSql(sql_result) SELECT CONCAT_WS('''',''insert into ', v_tableName, '(', getTableColumn(p_library_name, v_tableName, 1), ') values (', getTableColumn(p_library_name, v_tableName, 0), ');'') FROM ', v_tableName, ' WHERE OID in (select material_oid from t_pac_package_material_rel where package_oid=''', p_packageOid, ''');');
	set @sql = v_sql;
	PREPARE s1 from @sql; 
	EXECUTE s1; 
	
	#套餐材料关系表
	set v_tableName = concat('t_pac_package_material_rel');
	insert into insertSql (sql_result) values (CONCAT('DELETE from ', v_tableName, ' where package_oid = ''', p_packageOid, ''';'));
	set v_sql = CONCAT('insert into insertSql(sql_result) SELECT CONCAT_WS('''',''insert into ', v_tableName, '(', getTableColumn(p_library_name, v_tableName, 1), ') values (', getTableColumn(p_library_name, v_tableName, 0), ');'') FROM ', v_tableName, ' WHERE package_oid = ''', p_packageOid, ''';');
	set @sql = v_sql;
	PREPARE s1 from @sql; 
	EXECUTE s1; 
	
	#套餐打印模板
	set v_tableName = concat('t_pac_print_template');
	insert into insertSql (sql_result) values (CONCAT('DELETE from ', v_tableName, ' where package_oid = ''', p_packageOid, ''';'));
	set v_sql = CONCAT('insert into insertSql(sql_result) SELECT CONCAT_WS('''',''insert into ', v_tableName, '(', getTableColumn(p_library_name, v_tableName, 1), ') values (', getTableColumn(p_library_name, v_tableName, 0), ');'') FROM ', v_tableName, ' WHERE package_oid = ''', p_packageOid, ''';');
	set @sql = v_sql;
	PREPARE s1 from @sql; 
	EXECUTE s1; 
	
	#套餐证照
	set v_tableName = concat('t_pac_licence');
	insert into insertSql (sql_result) values (CONCAT('DELETE from ', v_tableName, ' where package_oid = ''', p_packageOid, ''';'));
	set v_sql = CONCAT('insert into insertSql(sql_result) SELECT CONCAT_WS('''',''insert into ', v_tableName, '(', getTableColumn(p_library_name, v_tableName, 1), ') values (', getTableColumn(p_library_name, v_tableName, 0), ');'') FROM ', v_tableName, ' WHERE package_oid = ''', p_packageOid, ''';');
	set @sql = v_sql;
	PREPARE s1 from @sql; 
	EXECUTE s1; 
	
	#套餐告知单
	set v_tableName = concat('t_pac_inform');
	insert into insertSql (sql_result) values (CONCAT('DELETE from ', v_tableName, ' where package_oid = ''', p_packageOid, ''';'));
	set v_sql = CONCAT('insert into insertSql(sql_result) SELECT CONCAT_WS('''',''insert into ', v_tableName, '(', getTableColumn(p_library_name, v_tableName, 1), ') values (', getTableColumn(p_library_name, v_tableName, 0), ');'') FROM ', v_tableName, ' WHERE package_oid = ''', p_packageOid, ''';');
	set @sql = v_sql;
	PREPARE s1 from @sql; 
	EXECUTE s1; 
	
	#套餐告知单标签
	set v_tableName = concat('t_pac_inform_element');
	insert into insertSql (sql_result) values (CONCAT('DELETE from ', v_tableName, ' where package_oid = ''', p_packageOid, ''';'));
	set v_sql = CONCAT('insert into insertSql(sql_result) SELECT CONCAT_WS('''',''insert into ', v_tableName, '(', getTableColumn(p_library_name, v_tableName, 1), ') values (', getTableColumn(p_library_name, v_tableName, 0), ');'') FROM ', v_tableName, ' WHERE package_oid = ''', p_packageOid, ''';');
	set @sql = v_sql;
	PREPARE s1 from @sql; 
	EXECUTE s1; 
	
	#套餐细化材料配置关系表
	set v_tableName = concat('t_pac_mate_config_rel');
	insert into insertSql (sql_result) values (CONCAT('DELETE from ', v_tableName, ' where package_oid = ''', p_packageOid, ''';'));
	set v_sql = CONCAT('insert into insertSql(sql_result) SELECT CONCAT_WS('''',''insert into ', v_tableName, '(', getTableColumn(p_library_name, v_tableName, 1), ') values (', getTableColumn(p_library_name, v_tableName, 0), ');'') FROM ', v_tableName, ' WHERE package_oid = ''', p_packageOid, ''';');
	set @sql = v_sql;
	PREPARE s1 from @sql; 
	EXECUTE s1; 
	
	#套餐选项字段值关系表
	set v_tableName = concat('t_pac_opt_field_val_rel');
	insert into insertSql (sql_result) values (CONCAT('DELETE from ', v_tableName, ' where package_oid = ''', p_packageOid, ''';'));
	set v_sql = CONCAT('insert into insertSql(sql_result) SELECT CONCAT_WS('''',''insert into ', v_tableName, '(', getTableColumn(p_library_name, v_tableName, 1), ') values (', getTableColumn(p_library_name, v_tableName, 0), ');'') FROM ', v_tableName, ' WHERE package_oid = ''', p_packageOid, ''';');
	set @sql = v_sql;
	PREPARE s1 from @sql; 
	EXECUTE s1; 
	
	#套餐选项值、告知单标签关系表
	set v_tableName = concat('t_pac_opt_inform_element_rel');
	insert into insertSql (sql_result) values (CONCAT('DELETE from ', v_tableName, ' where package_oid = ''', p_packageOid, ''';'));
	set v_sql = CONCAT('insert into insertSql(sql_result) SELECT CONCAT_WS('''',''insert into ', v_tableName, '(', getTableColumn(p_library_name, v_tableName, 1), ') values (', getTableColumn(p_library_name, v_tableName, 0), ');'') FROM ', v_tableName, ' WHERE package_oid = ''', p_packageOid, ''';');
	set @sql = v_sql;
	PREPARE s1 from @sql; 
	EXECUTE s1; 
	
	#套餐选项证照关系表 
	set v_tableName = concat('t_pac_opt_lice_rel');
	insert into insertSql (sql_result) values (CONCAT('DELETE from ', v_tableName, ' where package_oid = ''', p_packageOid, ''';'));
	set v_sql = CONCAT('insert into insertSql(sql_result) SELECT CONCAT_WS('''',''insert into ', v_tableName, '(', getTableColumn(p_library_name, v_tableName, 1), ') values (', getTableColumn(p_library_name, v_tableName, 0), ');'') FROM ', v_tableName, ' WHERE package_oid = ''', p_packageOid, ''';');
	set @sql = v_sql;
	PREPARE s1 from @sql; 
	EXECUTE s1; 
	
	#套餐选项值材料关系表
	set v_tableName = concat('t_pac_opt_material_rel');
	insert into insertSql (sql_result) values (CONCAT('DELETE from ', v_tableName, ' where package_oid = ''', p_packageOid, ''';'));
	set v_sql = CONCAT('insert into insertSql(sql_result) SELECT CONCAT_WS('''',''insert into ', v_tableName, '(', getTableColumn(p_library_name, v_tableName, 1), ') values (', getTableColumn(p_library_name, v_tableName, 0), ');'') FROM ', v_tableName, ' WHERE package_oid = ''', p_packageOid, ''';');
	set @sql = v_sql;
	PREPARE s1 from @sql; 
	EXECUTE s1; 
	
	#套餐选项阻塞提醒表
	set v_tableName = concat('t_pac_opt_warning');
	insert into insertSql (sql_result) values (CONCAT('DELETE from ', v_tableName, ' where package_oid = ''', p_packageOid, ''';'));
	set v_sql = CONCAT('insert into insertSql(sql_result) SELECT CONCAT_WS('''',''insert into ', v_tableName, '(', getTableColumn(p_library_name, v_tableName, 1), ') values (', getTableColumn(p_library_name, v_tableName, 0), ');'') FROM ', v_tableName, ' WHERE package_oid = ''', p_packageOid, ''';');
	set @sql = v_sql;
	PREPARE s1 from @sql; 
	EXECUTE s1; 
	
	#套餐选项打印关联关系表
	set v_tableName = concat('t_pac_option_print_temp_rel');
	insert into insertSql (sql_result) values (CONCAT('DELETE from ', v_tableName, ' where package_oid = ''', p_packageOid, ''';'));
	set v_sql = CONCAT('insert into insertSql(sql_result) SELECT CONCAT_WS('''',''insert into ', v_tableName, '(', getTableColumn(p_library_name, v_tableName, 1), ') values (', getTableColumn(p_library_name, v_tableName, 0), ');'') FROM ', v_tableName, ' WHERE package_oid = ''', p_packageOid, ''';');
	set @sql = v_sql;
	PREPARE s1 from @sql; 
	EXECUTE s1; 
	
	#套餐情形关联表
	set v_tableName = concat('t_pac_situa_rel');
	insert into insertSql (sql_result) values (CONCAT('DELETE from ', v_tableName, ' where PAC_SITUATION_OID in (select oid from t_pac_situation where package_oid=''', p_packageOid, ''');'));
	set v_sql = CONCAT('insert into insertSql(sql_result) SELECT CONCAT_WS('''',''insert into ', v_tableName, '(', getTableColumn(p_library_name, v_tableName, 1), ') values (', getTableColumn(p_library_name, v_tableName, 0), ');'') FROM ', v_tableName, ' WHERE PAC_SITUATION_OID in (select oid from t_pac_situation where package_oid=''', p_packageOid, ''');');
	set @sql = v_sql;
	PREPARE s1 from @sql; 
	EXECUTE s1; 
	
	#套餐情形关联配置记录表 
	set v_tableName = concat('t_pac_situa_rel_record');
	insert into insertSql (sql_result) values (CONCAT('DELETE from ', v_tableName, ' where package_oid = ''', p_packageOid, ''';'));
	set v_sql = CONCAT('insert into insertSql(sql_result) SELECT CONCAT_WS('''',''insert into ', v_tableName, '(', getTableColumn(p_library_name, v_tableName, 1), ') values (', getTableColumn(p_library_name, v_tableName, 0), ');'') FROM ', v_tableName, ' WHERE package_oid = ''', p_packageOid, ''';');
	set @sql = v_sql;
	PREPARE s1 from @sql; 
	EXECUTE s1;
	
	#套餐情形选项关联信息表  
	set v_tableName = concat('t_pac_situation_opt_rel');
	insert into insertSql (sql_result) values (CONCAT('DELETE from ', v_tableName, ' where package_oid = ''', p_packageOid, ''';'));
	set v_sql = CONCAT('insert into insertSql(sql_result) SELECT CONCAT_WS('''',''insert into ', v_tableName, '(', getTableColumn(p_library_name, v_tableName, 1), ') values (', getTableColumn(p_library_name, v_tableName, 0), ');'') FROM ', v_tableName, ' WHERE package_oid = ''', p_packageOid, ''';');
	set @sql = v_sql;
	PREPARE s1 from @sql; 
	EXECUTE s1;
	
	#套餐选项值字段关系表 
	set v_tableName = concat('t_pac_opt_field_rel');
	insert into insertSql (sql_result) values (CONCAT('DELETE from ', v_tableName, ' where package_oid = ''', p_packageOid, ''';'));
	set v_sql = CONCAT('insert into insertSql(sql_result) SELECT CONCAT_WS('''',''insert into ', v_tableName, '(', getTableColumn(p_library_name, v_tableName, 1), ') values (', getTableColumn(p_library_name, v_tableName, 0), ');'') FROM ', v_tableName, ' WHERE package_oid = ''', p_packageOid, ''';');
	set @sql = v_sql;
	PREPARE s1 from @sql; 
	EXECUTE s1;
	
	insert into insertSql values ('	IF @error = 1 THEN ');
	insert into insertSql values ('		SELECT CONCAT(\'执行出错回滚，错误信息\', msg);');
	insert into insertSql values ('		ROLLBACK;');
	insert into insertSql values ('	ELSE ');
	insert into insertSql values ('		SELECT \'成功\';');
	insert into insertSql values ('		COMMIT;');
	insert into insertSql values ('	END IF;');
	insert into insertSql values ('end;');
	insert into insertSql values ('call insert_sql_proc();');
	insert into insertSql values ('drop PROCEDURE insert_sql_proc;');
	
	select * from insertSql;

END;

