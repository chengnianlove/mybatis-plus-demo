create definer = root@`%` view v_t_pac_case as
select `zf_ahs_platform_pudong`.`t_pac_case`.`PACKAGE_OID`   AS `PACKAGE_OID`,
       `zf_ahs_platform_pudong`.`t_pac_case`.`PAC_CASE_CODE` AS `PAC_CASE_CODE`,
       `zf_ahs_platform_pudong`.`t_pac_case`.`PACKAGE_NAME`  AS `PACKAGE_NAME`
from `zf_ahs_platform_pudong`.`t_pac_case`;

