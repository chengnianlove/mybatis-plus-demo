create definer = root@localhost view v_package as
select `p`.`OID` AS `OID`, `p`.`PACKAGE_NAME` AS `PACKAGE_NAME`
from `zf_ahs_platform_pudong`.`t_pac_package` `p`
where (`p`.`DELETE_STATUS` = 'N');

