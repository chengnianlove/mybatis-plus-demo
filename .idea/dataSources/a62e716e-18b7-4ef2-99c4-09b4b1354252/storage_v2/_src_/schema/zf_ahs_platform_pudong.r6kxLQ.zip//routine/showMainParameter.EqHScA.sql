create
    definer = root@`%` procedure showMainParameter()
BEGIN
select COUNT(DISTINCT OPER_USER_OID) from t_sys_log where OPER_DATE>=DATE_SUB(CURDATE(), INTERVAL 7 DAY);
select count(*) from t_sys_user;
select count(*) from t_sys_app;
select COUNT(*) from t_workflow_buss_info;
END;

