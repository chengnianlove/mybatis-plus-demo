create
    definer = root@`%` function checkEmptyStr(str longtext) returns text
BEGIN
  DECLARE v_names longtext DEFAULT '';
  
  set v_names = CONCAT('\'', str, '\'');
  
  if str is null or str = '' THEN
    set v_names = 'null';
  end if;
  
  RETURN v_names;
END;

