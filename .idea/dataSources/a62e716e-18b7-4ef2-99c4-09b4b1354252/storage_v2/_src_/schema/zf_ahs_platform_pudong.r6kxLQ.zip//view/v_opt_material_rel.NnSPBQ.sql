create definer = root@localhost view v_opt_material_rel as
select `o`.`OID`           AS `OID`,
       `o`.`PACKAGE_OID`   AS `PACKAGE_OID`,
       `o`.`OPTION_OIDS`   AS `OPTION_OIDS`,
       `o`.`MATERIAL_OIDS` AS `MATERIAL_OIDS`
from `zf_ahs_platform_pudong`.`t_pac_opt_material_rel` `o`
where (`o`.`DELETE_STATUS` = 'N');

